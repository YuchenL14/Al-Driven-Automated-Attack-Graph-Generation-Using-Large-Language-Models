"""
build_from_json.py -- turn a validated AttackGraphModel (Stage 3 output)
into a rendered attack graph (Stage 4). This is the seam where the future
LLM extraction stage plugs in: produce JSON -> validate -> render.

Run a demo from the project root:
    python examples/build_from_json.py
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from schema import AttackGraphModel
from attack_graph import AttackGraph, Precondition, Event


def render_from_model(model: AttackGraphModel, out_path: str) -> str:
    ag = AttackGraph(model.title)
    for p in model.preconditions:
        ag.add_precondition(Precondition(p.id, p.text, p.code))
    for e in model.events:
        ag.add_event(Event(e.id, e.text, e.marker, e.technique,
                           list(e.mitigations), e.likelihood))
    for src, dst in model.edges:
        ag.connect(src, dst)
    return ag.render(out_path)


def render_from_json(data: dict, out_path: str) -> str:
    return render_from_model(AttackGraphModel(**data), out_path)


if __name__ == "__main__":
    # Stand-in for what the LLM will eventually emit from a report PDF.
    demo = {
        "title": "demo_from_json",
        "preconditions": [
            {"id": "p1", "text": "Unpatched internet-facing VPN", "code": "RS"},
            {"id": "p2", "text": "Valid stolen credentials", "code": "CA"},
        ],
        "events": [
            {"id": "e1", "text": "Exploit VPN to gain initial access",
             "marker": "IA", "technique": "T1190",
             "mitigations": ["M1051"], "likelihood": 6.0},
            {"id": "e2", "text": "Deploy ransomware across network",
             "marker": "IM", "technique": "T1486",
             "mitigations": ["M1040"], "likelihood": 5.0},
        ],
        "edges": [["p1", "e1"], ["p2", "e1"], ["e1", "e2"]],
    }
    out = render_from_json(demo, "output/demo_from_json")
    print(f"Wrote {out}")
