"""
ingest.py -- Stage 2 of the pipeline: turn a source document into clean text.

A real incident report usually arrives as a PDF. markitdown converts it to
clean, LLM-ready text in one call. Plain-text and markdown files are read
directly. The output of this stage is a single string that the extraction
stage (Stage 3) will read.
"""

from __future__ import annotations

from pathlib import Path


def ingest(path: str | Path) -> str:
    """Return the clean text of a report at `path` (.pdf, .txt, .md, .docx...)."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"report not found: {p}")

    suffix = p.suffix.lower()
    if suffix in {".txt", ".md"}:
        return p.read_text(encoding="utf-8")

    # everything else (pdf, docx, html, pptx...) goes through markitdown
    from markitdown import MarkItDown
    md = MarkItDown(enable_plugins=False)
    result = md.convert(str(p))
    text = result.text_content.strip()
    if not text:
        raise ValueError(f"no text could be extracted from {p}")
    return text


if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("usage: python ingest.py <report.pdf|report.txt>")
        raise SystemExit(1)
    out = ingest(sys.argv[1])
    print(f"[ok] extracted {len(out)} characters")
    print("-" * 60)
    print(out[:800])
