# attack-graph-tool

Prototype that turns a cyber attack report into a MITRE ATT&CK-aligned attack
graph. It reads a PDF or text report, uses a language model to extract the
preconditions, events, technique (T) numbers and mitigation (M) numbers, and
renders the graph.

## Pipeline
    report (PDF/text)
      -> src/ingest.py    Stage 2  clean text (markitdown)
      -> src/extract.py   Stage 3  validated AttackGraph (LLM, pluggable)
      -> src/attack_graph.py  Stage 4  attack graph PNG

## Layout
    src/schema.py         canonical JSON contract (Pydantic) + validation
    src/attack_lookup.py  ATT&CK code -> name + auto legend
    src/attack_graph.py   networkx DAG validation + Graphviz rendering
    src/ingest.py         PDF/text -> clean text
    src/extract.py        text -> AttackGraph via ollama | anthropic | mock
    data/attack_lookup.json   offline ATT&CK name map
    examples/             sample report, mock extraction, demo scripts

## Requirements
* Python 3.12 (conda env: python_project)
* Graphviz system binary (dot) on PATH
* pip install -r requirements.txt
* For real extraction: either Ollama running locally, or ANTHROPIC_API_KEY set

## Run
    # offline, no model needed (checks the whole pipeline):
    python examples/generate_from_report.py examples/sample_report.txt mock

    # real extraction with a local model:
    python examples/generate_from_report.py examples/sample_report.pdf ollama

    # real extraction with the Claude API:
    python examples/generate_from_report.py my_incident.pdf anthropic

## Design note
Every provider must emit JSON that passes the schema contract before a graph is
drawn. A hallucinated or malformed element is rejected, the error is fed back to
the model, and extraction is retried, so the renderer never draws bad data.
