"""
attack_graph.py -- the rendering engine.

PIPELINE (Stage 4 of the tool)
------------------------------
    AttackGraph (validated schema)
        -> networkx.DiGraph        # structural model + DAG validation
        -> graphviz.Digraph        # visual model (Lallie 2020 syntax)
        -> PNG / PDF / SVG

WHY TWO GRAPH LIBRARIES?
  * networkx gives us a real directed graph we can *reason about*: we check it
    is acyclic (an attack path cannot loop back on itself), and the same object
    is the natural place to add path / centrality analysis later. This is what
    lifts the tool above "a script that draws boxes".
  * graphviz owns only the drawing. Keeping the two apart means the visual
    style can change (e.g. an SVG backend for pixel-perfect badges) without
    touching the logic.

VISUAL SYNTAX (grounded in Lallie, Debattista & Bal 2020)
  * Precondition -> ellipse, code badge top-left.
  * Event -> rectangle with four corner badges:
        top-left  = tactic (lavender)      top-right    = technique T# (red)
        bottom-left = likelihood (teal)     bottom-right = mitigation M# (orange)
  * Precondition logic -> an explicit AND / OR gate node when several parents
    converge on one event (a first-class construct in Lallie 2020).
"""

from __future__ import annotations

from pathlib import Path

import networkx as nx
from graphviz import Digraph

from schema import AttackGraph
from attack_lookup import AttackResolver
from reference_renderer import render_reference_png
import html
import re


def model_tag(provider: str | None, model: str | None) -> str:
    """Build a short, filename-safe tag for the model that produced a graph.

    The tag lets one report generate a separate output per model instead of
    overwriting a previous run. Examples:
        provider="anthropic", model="claude-sonnet-5" -> "anthropic-claude-sonnet-5"
        provider="ollama",    model="qwen3:8b"        -> "ollama-qwen3-8b"
        provider="mock",      model=None              -> "mock"
    """
    parts = [p for p in (provider, model) if p]
    raw = "-".join(parts) if parts else "unknown"
    # replace any character that is awkward in a file name with a hyphen
    safe = re.sub(r"[^A-Za-z0-9._-]+", "-", raw)
    return safe.strip("-.") or "unknown"


def tagged_output_path(outputs_dir: Path, report_stem: str,
                       provider: str | None, model: str | None) -> Path:
    """Return the next numbered PNG path for one report/rule/model combination.

    A generation run is an experimental observation.  Keeping it, rather than
    overwriting a previous run with the same settings, makes repeated LLM runs
    comparable and reproducible.  For example, the first two v1.4 Claude runs
    are saved as ``...__rules-v1.4__anthropic-claude-sonnet-5_1.png`` and
    ``..._2.png``.  The same reservation also detects the ``_part1`` / ``_part2``
    files produced by split rendering.
    """
    base = outputs_dir / f"{report_stem}__{model_tag(provider, model)}"
    run = 1
    while True:
        candidate = base.with_name(f"{base.name}_{run}.png")
        split_part_1 = base.with_name(f"{base.name}_{run}_part1.png")
        split_part_2 = base.with_name(f"{base.name}_{run}_part2.png")
        if not any(path.exists() for path in (candidate, split_part_1, split_part_2)):
            return candidate
        run += 1


def _esc(s) -> str:
    """Escape &, <, > so text is safe inside Graphviz HTML-like labels."""
    return html.escape(str(s), quote=False)

# --- palette (matches the existing four-colour badge scheme) ----------------
C_TACTIC = "#b6a8d6"      # lavender
C_TECH = "#e8918c"        # red
C_LIKELIHOOD = "#4ec9b0"  # teal
C_MITIG = "#f4b860"       # orange
C_BORDER = "#33415e"      # dark slate
C_TEXT = "#1a1a2e"
FONT = "Helvetica"


# ---------------------------------------------------------------------------
# structural model + validation
# ---------------------------------------------------------------------------
def build_digraph(model: AttackGraph) -> nx.DiGraph:
    """Build a networkx DiGraph and assert it is a DAG."""
    g = nx.DiGraph()
    for p in model.preconditions:
        g.add_node(p.id, kind="precondition")
        for parent in p.parents:
            g.add_edge(parent, p.id)
    for e in model.events:
        g.add_node(e.id, kind="event")
        for parent in e.parents:
            g.add_edge(parent, e.id)
    if not nx.is_directed_acyclic_graph(g):
        cycle = nx.find_cycle(g)
        raise ValueError(f"attack graph is not acyclic; cycle found: {cycle}")
    return g


# ---------------------------------------------------------------------------
# HTML-like label helpers
# ---------------------------------------------------------------------------
def _badge(text: str, bg: str) -> str:
    """A small rounded colour badge (one-cell nested table)."""
    return (
        f'<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" '
        f'BGCOLOR="{bg}" STYLE="ROUNDED"><TR><TD>'
        f'<FONT POINT-SIZE="10" COLOR="{C_TEXT}"><B>{_esc(text)}</B></FONT>'
        f'</TD></TR></TABLE>'
    )


def _stacked_badges(items: list[str], bg: str) -> str:
    """Several badges stacked vertically (e.g. multiple M-numbers)."""
    if not items:
        return ""
    rows = "".join(f'<TR><TD ALIGN="RIGHT">{_badge(i, bg)}</TD></TR>' for i in items)
    return f'<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="2">{rows}</TABLE>'


def _event_label(e) -> str:
    tactic = _badge(e.tactic, C_TACTIC)
    tech = _badge(e.technique, C_TECH) if e.technique else ""
    like = _badge(f"{e.likelihood:.1f}", C_LIKELIHOOD) if e.likelihood is not None else ""
    mitig = _stacked_badges(e.mitigations, C_MITIG)
    body = f'<FONT POINT-SIZE="12" COLOR="{C_TEXT}">{_esc(e.label)}</FONT>'
    return (
        '<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6">'
        f'<TR><TD ALIGN="LEFT">{tactic}</TD><TD></TD><TD ALIGN="RIGHT">{tech}</TD></TR>'
        f'<TR><TD COLSPAN="3" ALIGN="CENTER">{body}</TD></TR>'
        f'<TR><TD ALIGN="LEFT">{like}</TD><TD></TD><TD ALIGN="RIGHT">{mitig}</TD></TR>'
        '</TABLE>>'
    )


def _precondition_label(p) -> str:
    code = _badge(p.code, C_TACTIC)
    body = f'<FONT POINT-SIZE="12" COLOR="{C_TEXT}">{_esc(p.label)}</FONT>'
    return (
        '<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="4">'
        f'<TR><TD ALIGN="LEFT">{code}</TD></TR>'
        f'<TR><TD>{body}</TD></TR>'
        '</TABLE>>'
    )


def _legend_label(legend: dict) -> str:
    rows = []
    for group, items in legend.items():
        if not items:
            continue
        rows.append(
            f'<TR><TD ALIGN="LEFT" COLSPAN="2">'
            f'<FONT POINT-SIZE="11" COLOR="{C_BORDER}"><B>{_esc(group)}</B></FONT></TD></TR>'
        )
        for code, name in items.items():
            rows.append(
                f'<TR><TD ALIGN="LEFT"><FONT POINT-SIZE="10" COLOR="{C_TEXT}">{_esc(code)}</FONT></TD>'
                f'<TD ALIGN="LEFT"><FONT POINT-SIZE="10" COLOR="{C_TEXT}">{_esc(name)}</FONT></TD></TR>'
            )
    return (
        '<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="1" CELLPADDING="3" '
        f'COLOR="{C_BORDER}">' + "".join(rows) + '</TABLE>>'
    )


# ---------------------------------------------------------------------------
# render
# ---------------------------------------------------------------------------
def _render_graphviz(model: AttackGraph, out_path: str, fmt: str = "png",
                     dpi: int = 170, resolver: AttackResolver | None = None,
                     compact: bool = False) -> str:
    """Validate, then render the attack graph. Returns the written file path.

    compact pairs each event with the precondition it produces on one rank and
    tightens the spacing, which roughly halves the height of a long alternating
    chain so the figure fits on a page. The default layout gives each node its
    own rank, which reads more clearly on its own.
    """
    build_digraph(model)                     # <-- raises if not a DAG
    if not model.events and not model.preconditions:
        raise ValueError(
            "the model produced no attack steps from this report. This usually "
            "means the source has little technical attack detail (for example a "
            "news article rather than a technical report). Try a report that "
            "describes the attack steps."
        )
    resolver = resolver or AttackResolver()

    dot = Digraph("attack_graph", format=fmt)
    if compact:
        # compact mode: very tight spacing for the shortest possible figure
        dot.attr(rankdir="TB", bgcolor="white", splines="true",
                 nodesep="0.28", ranksep="0.18", ratio="auto")
    else:
        # default mode: tightened rank separation so a long chain does not run
        # off the page, with ratio=auto letting dot settle a sensible height to
        # width balance. These follow the Graphviz guidance on compacting a
        # drawing by reducing ranksep and nodesep.
        dot.attr(rankdir="TB", bgcolor="white", splines="true",
                 nodesep="0.4", ranksep="0.4", ratio="auto")
    dot.attr("node", fontname=FONT)
    dot.attr("edge", color=C_BORDER, penwidth="1.2", arrowsize="0.8")

    # in compact mode, an event and the single precondition it produces are kept
    # tight and vertical, so the alternating chain reads like the target figure
    # rather than spreading across the page
    tight_pairs = set()
    if compact:
        event_ids = {e.id for e in model.events}
        produced = set()
        for p in model.preconditions:
            if len(p.parents) == 1 and p.parents[0] in event_ids \
                    and p.parents[0] not in produced:
                tight_pairs.add((p.parents[0], p.id))
                produced.add(p.parents[0])

    # preconditions (ellipses)
    for p in model.preconditions:
        dot.node(p.id, label=_precondition_label(p), shape="ellipse",
                 color=C_BORDER, penwidth="1.4")

    # events (rectangles)
    for e in model.events:
        dot.node(e.id, label=_event_label(e), shape="box",
                 color=C_BORDER, penwidth="1.6")

    # edges + precondition logic (AND / OR gates)
    for p in model.preconditions:
        for parent in p.parents:          # event that establishes this precondition
            if (parent, p.id) in tight_pairs:
                dot.edge(parent, p.id, weight="12", minlen="1")
            else:
                dot.edge(parent, p.id)
    for e in model.events:
        if len(e.parents) <= 1:
            for parent in e.parents:
                dot.edge(parent, e.id)
        else:
            gate_id = f"__gate_{e.id}"
            dot.node(gate_id, label=e.join, shape="diamond",
                     style="filled", fillcolor="#eeeef4", color=C_BORDER,
                     fontsize="10", width="0.4", height="0.4", fixedsize="true")
            for parent in e.parents:
                dot.edge(parent, gate_id)
            dot.edge(gate_id, e.id)

    # auto-generated legend (only if there is something to decode)
    legend = resolver.build_legend(model)
    if any(items for items in legend.values()):
        dot.node("__legend", label=_legend_label(legend), shape="plaintext")

    dot.attr(dpi=str(dpi))
    out = Path(out_path)
    written = dot.render(filename=out.stem, directory=str(out.parent), cleanup=True)
    return written


def render(model: AttackGraph, out_path: str, fmt: str = "png",
           dpi: int = 170, resolver: AttackResolver | None = None,
           compact: bool = False) -> str:
    """Render an attack graph without changing the extraction/data pipeline.

    PNG is the user-facing output of the application, so it uses the bespoke
    renderer that reproduces the visual language of ``SampleCyberAttackGraph``:
    external circular badges, compact white nodes, orthogonal connector buses,
    and an unboxed ATT&CK legend.  SVG and PDF remain on the established
    Graphviz path so existing callers that request those formats keep working.

    ``dpi`` is retained for API compatibility.  The reference PNG renderer
    deliberately works in screen pixels, rather than Graphviz's DPI-scaled
    canvas, so its typography and badge sizes stay consistent with the sample.
    """
    if fmt.lower() != "png":
        return _render_graphviz(model, out_path, fmt=fmt, dpi=dpi,
                                resolver=resolver, compact=compact)

    build_digraph(model)
    if not model.events and not model.preconditions:
        raise ValueError(
            "the model produced no attack steps from this report. This usually "
            "means the source has little technical attack detail (for example a "
            "news article rather than a technical report). Try a report that "
            "describes the attack steps."
        )
    return render_reference_png(model, out_path, resolver=resolver,
                                compact=compact)


if __name__ == "__main__":
    # tiny smoke test
    from schema import Precondition, Event
    g = AttackGraph(
        title="smoke",
        preconditions=[Precondition(id="p1", label="Unpatched VPN", code="RS")],
        events=[Event(id="e1", label="Exploit VPN", tactic="IA",
                      technique="T1190", mitigations=["M1051"], likelihood=6.0,
                      parents=["p1"])],
    )
    print(render(g, "smoke_test.png"))

# ---------------------------------------------------------------------------
# optional split of a long graph into two semantically ordered halves
# ---------------------------------------------------------------------------
EARLY_TACTICS = {"RE", "RS", "IA", "EX", "PS", "PE", "CA", "DE"}
LATE_TACTICS = {"DS", "LM", "CL", "C2", "EF", "IM"}


def _anchor_precondition(p):
    """A copy of a precondition with no parents, used as a bridge anchor."""
    return p.model_copy(update={"parents": []})


def _submodel(model, keep_event_ids, keep_pre_ids, title):
    """Build a valid AttackGraph from a subset, adding bridge anchors so that
    every parent reference still resolves."""
    from schema import AttackGraph
    ev_by_id = {e.id: e for e in model.events}
    pre_by_id = {p.id: p for p in model.preconditions}

    events, preconditions = [], []
    present = set(keep_event_ids) | set(keep_pre_ids)

    # events in this half; drop parent refs that fall outside this half
    for e in model.events:
        if e.id in keep_event_ids:
            parents = [pid for pid in e.parents if pid in present]
            events.append(e.model_copy(update={"parents": parents}))

    # preconditions in this half; a produced-by parent outside the half becomes
    # a root here (its anchor is shown so the reader sees the join point)
    for p in model.preconditions:
        if p.id in keep_pre_ids:
            parents = [pid for pid in p.parents if pid in present]
            preconditions.append(p.model_copy(update={"parents": parents}))

    return AttackGraph(title=title, preconditions=preconditions, events=events)


def render_split(model, out_path: str, fmt: str = "png", dpi: int = 170,
                 compact: bool = True, threshold: int = 12):
    """Render the graph, splitting it into two files when it is long.

    A graph with more than `threshold` events is divided by tactic into an
    early half (intrusion and privilege escalation) and a late half (lateral
    movement and impact). A precondition that links the two halves appears in
    both, so neither half is cut off mid chain. Returns a list of written paths.
    """
    if len(model.events) <= threshold:
        return [render(model, out_path, fmt=fmt, dpi=dpi, compact=compact)]

    early_ev = {e.id for e in model.events if e.tactic in EARLY_TACTICS}
    late_ev = {e.id for e in model.events if e.id not in early_ev}
    ev_by_id = {e.id: e for e in model.events}

    def side_of_event(eid):
        return "early" if eid in early_ev else "late"

    # assign preconditions to a side by the events they touch; a precondition
    # can belong to both, which makes it the bridge shown in each half
    early_pre, late_pre = set(), set()
    consumers = {}
    for e in model.events:
        for pid in e.parents:
            consumers.setdefault(pid, []).append(e.id)
    for p in model.preconditions:
        touching = list(p.parents) + consumers.get(p.id, [])
        sides = {side_of_event(x) for x in touching if x in ev_by_id}
        if not sides:
            early_pre.add(p.id)
        if "early" in sides:
            early_pre.add(p.id)
        if "late" in sides:
            late_pre.add(p.id)

    out = Path(out_path)
    m1 = _submodel(model, early_ev, early_pre, model.title + " (part 1 of 2)")
    m2 = _submodel(model, late_ev, late_pre, model.title + " (part 2 of 2)")
    p1 = render(m1, str(out.with_name(out.stem + "_part1.png")), fmt=fmt,
                dpi=dpi, compact=compact)
    p2 = render(m2, str(out.with_name(out.stem + "_part2.png")), fmt=fmt,
                dpi=dpi, compact=compact)
    return [p1, p2]
