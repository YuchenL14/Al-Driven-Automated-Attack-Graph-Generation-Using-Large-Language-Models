"""
schema.py -- the canonical data contract for the attack-graph tool.

DESIGN NOTE (Approach C: dual-input, single contract)
-----------------------------------------------------
Every input route -- an analyst filling in JSON by hand today, or an LLM
extracting elements from a narrative report tomorrow -- must converge on ONE
validated object model. The rendering engine only ever sees this model, so it
never needs to know where the data came from. This file *is* that contract.

The constructs mirror the primary constructs identified in
Lallie, Debattista & Bal (2020): a *precondition*, an *event* (exploit), and
*precondition logic* (AND / OR). Grounding the schema in that visual-syntax
theory is what makes the graph a faithful implementation rather than an
arbitrary drawing.

The two known fidelity issues are fixed *here*, at the contract, so bad data
can never reach the renderer:
  1. Sub-technique notation must be T####.### (three digits), so "T1566.02"
     is rejected in favour of "T1566.002".
  2. The tactic marker must be a real ATT&CK tactic abbreviation, so the old
     Kill-Chain letters (D / E / I) can no longer be mixed in.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

# --- The 14 MITRE ATT&CK Enterprise tactics (abbreviation -> canonical) ------
# Used to REJECT non-ATT&CK tactic markers (fixes the mixed-scheme issue).
ATTACK_TACTICS = {
    "RE": "Reconnaissance",
    "RS": "Resource Development",
    "IA": "Initial Access",
    "EX": "Execution",
    "PS": "Persistence",
    "PE": "Privilege Escalation",
    "DE": "Defense Evasion",
    "CA": "Credential Access",
    "DS": "Discovery",
    "LM": "Lateral Movement",
    "CL": "Collection",
    "C2": "Command and Control",
    "EF": "Exfiltration",
    "IM": "Impact",
}

# Technique id: T#### optionally .### (three-digit sub-technique).  Fixes .02 -> .002
TECHNIQUE_RE = re.compile(r"^T\d{4}(\.\d{3})?$")
MITIGATION_RE = re.compile(r"^M\d{4}$")

# --- known ATT&CK ids (the closed vocabulary the tool supports) -------------
# Loaded from the same offline lookup used for the legend. A technique or
# mitigation id must exist here, which stops a model inventing a plausible but
# non-existent id such as M1052. Extend data/attack_lookup.json to widen it.
_LOOKUP = Path(__file__).resolve().parent.parent / "data" / "attack_lookup.json"
try:
    _raw = json.loads(_LOOKUP.read_text(encoding="utf-8"))
    KNOWN_TECHNIQUES = set(_raw.get("techniques", {}))
    KNOWN_MITIGATIONS = set(_raw.get("mitigations", {}))
except Exception:                       # fall back to format-only if file missing
    KNOWN_TECHNIQUES = set()
    KNOWN_MITIGATIONS = set()


class Precondition(BaseModel):
    """An ellipse.  A state that must hold before an event can happen.

    A precondition may be a root (an initial resource, no parents) or it may be
    *produced* by an event -- e.g. the event 'Create extension' establishes the
    precondition 'extension available on store'. This precondition/exploit
    alternation is the classic attack-graph structure (Lallie 2020, MulVAL).
    """
    id: str
    label: str = Field(..., description="<= 10 words, shown inside the ellipse")
    code: str = Field(..., description="short badge shown top-left, e.g. 'RS', 'R'")
    parents: List[str] = Field(default_factory=list,
                               description="event ids that establish this precondition")

    @field_validator("label")
    @classmethod
    def _max_ten_words(cls, v: str) -> str:
        if len(v.split()) > 10:
            raise ValueError(f"precondition label must be <= 10 words, got: {v!r}")
        return v


class Event(BaseModel):
    """A rectangle.  An action the adversary performs (an exploit)."""
    id: str
    label: str
    tactic: str = Field(..., description="ATT&CK tactic abbreviation, top-left")
    technique: Optional[str] = Field(None, description="T-number, top-right")
    mitigations: List[str] = Field(default_factory=list, description="M-numbers, bottom-right")
    likelihood: Optional[float] = Field(None, ge=0, le=10, description="bottom-left, 0-10")
    # precondition logic: which nodes feed this event, and how they combine
    parents: List[str] = Field(default_factory=list)
    join: Literal["AND", "OR"] = "AND"

    @field_validator("tactic")
    @classmethod
    def _known_tactic(cls, v: str) -> str:
        if v not in ATTACK_TACTICS:
            raise ValueError(
                f"tactic {v!r} is not an ATT&CK abbreviation. "
                f"Use one of: {', '.join(ATTACK_TACTICS)}"
            )
        return v

    @field_validator("technique")
    @classmethod
    def _valid_technique(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        if not TECHNIQUE_RE.match(v):
            raise ValueError(
                f"technique {v!r} is malformed. Expected T#### or T####.### "
                f"(three-digit sub-technique, e.g. T1566.002)."
            )
        if KNOWN_TECHNIQUES and v not in KNOWN_TECHNIQUES:
            raise ValueError(
                f"technique {v!r} is not a real ATT&CK technique in this tool's set. "
                f"Choose an existing technique id, do not invent one."
            )
        return v

    @field_validator("mitigations")
    @classmethod
    def _valid_mitigations(cls, v: List[str]) -> List[str]:
        for m in v:
            if not MITIGATION_RE.match(m):
                raise ValueError(f"mitigation {m!r} is malformed. Expected M#### (e.g. M1051).")
            if KNOWN_MITIGATIONS and m not in KNOWN_MITIGATIONS:
                raise ValueError(
                    f"mitigation {m!r} is not a real ATT&CK mitigation in this tool's set. "
                    f"Choose an existing mitigation id, do not invent one."
                )
        return v


class AttackGraph(BaseModel):
    """The whole graph: the single object the renderer consumes."""
    title: str = "Attack Graph"
    preconditions: List[Precondition] = Field(default_factory=list)
    events: List[Event] = Field(default_factory=list)

    @model_validator(mode="after")
    def _check_references(self) -> "AttackGraph":
        """Every parent id an event or precondition names must actually exist."""
        known = {p.id for p in self.preconditions} | {e.id for e in self.events}
        for e in self.events:
            for parent in e.parents:
                if parent not in known:
                    raise ValueError(f"event {e.id!r} references unknown parent {parent!r}")
        for p in self.preconditions:
            for parent in p.parents:
                if parent not in known:
                    raise ValueError(f"precondition {p.id!r} references unknown parent {parent!r}")
        return self

    # ---- input adapters (Approach C) --------------------------------------
    @classmethod
    def from_json_file(cls, path: str | Path) -> "AttackGraph":
        """Route 1 (works today): load a canonical JSON file."""
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.model_validate(data)

    @classmethod
    def from_dict(cls, data: dict) -> "AttackGraph":
        """Route 2 (future): an LLM emits this dict from a narrative report."""
        return cls.model_validate(data)
