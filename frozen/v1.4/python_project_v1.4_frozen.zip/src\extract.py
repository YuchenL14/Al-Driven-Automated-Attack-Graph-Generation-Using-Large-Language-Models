"""
extract.py -- Stage 3 of the pipeline: read report text and produce a
validated AttackGraph, with a language model finding the preconditions,
events, ATT&CK technique (T) numbers, and mitigation (M) numbers.

The provider is pluggable, because the choice of model is still open:
  * "ollama"    -- a local model, nothing leaves the machine (BSREC low risk)
  * "anthropic" -- the Claude API, stronger extraction, needs an API key

Both are made to emit JSON that conforms to the schema contract. The contract
is the safety net: whatever the model produces has to pass validation before a
graph is drawn, so a hallucinated or malformed element is rejected rather than
rendered. When validation fails, the error is fed back and the model is asked
to correct itself, up to a small number of attempts.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from pydantic import BaseModel, Field, ValidationError, field_validator

from schema import (AttackGraph, ATTACK_TACTICS, KNOWN_TECHNIQUES,
                    KNOWN_MITIGATIONS, MITIGATION_RE, TECHNIQUE_RE)
from attack_graph import build_digraph
from attack_lookup import AttackResolver

# --- cleaning the model's output before validation -------------------------
# A model trained on an older ATT&CK release will sometimes use a tactic id
# (TA0001) or a full tactic name instead of the abbreviation this tool expects,
# or a technique id that has since been revoked. Rather than fail on these, we
# clean them up: map the tactic to its abbreviation, and drop any technique or
# mitigation id the current ATT&CK data no longer contains. The graph is still
# produced, just without the identifiers that no longer exist.
_TACTIC_ID_MAP = {
    "TA0043": "RE", "TA0042": "RS", "TA0001": "IA", "TA0002": "EX",
    "TA0003": "PS", "TA0004": "PE", "TA0005": "DE", "TA0006": "CA",
    "TA0007": "DS", "TA0008": "LM", "TA0009": "CL", "TA0011": "C2",
    "TA0010": "EF", "TA0040": "IM",
}
_TACTIC_NAME_MAP = {name.lower(): abbr for abbr, name in ATTACK_TACTICS.items()}


def _fix_tactic(t: str) -> str:
    if t in ATTACK_TACTICS:                 # already an abbreviation
        return t
    if t in _TACTIC_ID_MAP:                 # ATT&CK tactic id, e.g. TA0001
        return _TACTIC_ID_MAP[t]
    if t.lower() in _TACTIC_NAME_MAP:       # full name, e.g. "Initial Access"
        return _TACTIC_NAME_MAP[t.lower()]
    return t                                # leave it; validation will flag it


def _sanitize(raw_json: str) -> str:
    """Clean an LLM response so recoverable mistakes do not fail the whole graph."""
    try:
        data = json.loads(raw_json)
    except json.JSONDecodeError:
        return raw_json                     # let validation report the parse error

    # If the model did not return the expected object shape, do not try to clean
    # it. Hand it to validation unchanged so the schema reports the real problem
    # and the retry loop can ask the model to correct itself.
    if not isinstance(data, dict):
        return raw_json

    # Recover from double wrapping. A model sometimes returns the value of
    # "preconditions" or "events" as a JSON STRING that itself contains the whole
    # object, for example {"preconditions": "{\"preconditions\": [ ... ]}"}. Parse
    # such a string and lift out the array it holds, so a recoverable formatting
    # slip does not fail the graph.
    for key in ("preconditions", "events"):
        val = data.get(key)
        if isinstance(val, str):
            try:
                inner = json.loads(val)
            except json.JSONDecodeError:
                continue
            if isinstance(inner, list):
                data[key] = inner                     # the string held the array directly
            elif isinstance(inner, dict) and isinstance(inner.get(key), list):
                data[key] = inner[key]                # the string held {key: [...]}

    events = data.get("events", [])
    preconditions = data.get("preconditions", [])
    if not isinstance(events, list):
        events = []
    if not isinstance(preconditions, list):
        preconditions = []
    data["events"] = events
    data["preconditions"] = preconditions

    for e in events:
        if not isinstance(e, dict):
            continue                        # skip a malformed event, let validation catch it
        if isinstance(e.get("tactic"), str):
            e["tactic"] = _fix_tactic(e["tactic"])
        tech = e.get("technique")
        if tech and KNOWN_TECHNIQUES and tech not in KNOWN_TECHNIQUES:
            e["technique"] = None           # drop a revoked or unknown technique
        if isinstance(e.get("mitigations"), list) and KNOWN_MITIGATIONS:
            e["mitigations"] = [m for m in e["mitigations"] if m in KNOWN_MITIGATIONS]

    # drop parent references to nodes the model never defined (dangling edges)
    nodes = [n for n in (preconditions + events) if isinstance(n, dict)]
    known_ids = {n.get("id") for n in nodes}
    for n in nodes:
        if isinstance(n.get("parents"), list):
            n["parents"] = [p for p in n["parents"] if p in known_ids]

    return json.dumps(data)

# --- grounding: what the model must obey -----------------------------------
_TACTIC_LINES = "\n".join(f"  {abbr} = {name}" for abbr, name in ATTACK_TACTICS.items())

# The tool supports a fixed catalogue of ATT&CK ids. Giving the model that
# catalogue keeps it from inventing ids and lets the legend always resolve.
_resolver = AttackResolver()
_TECH_LINES = "\n".join(f"  {tid} = {name}" for tid, name in sorted(_resolver._techniques.items()))
_MITI_LINES = "\n".join(f"  {mid} = {name}" for mid, name in sorted(_resolver._mitigations.items()))

# --- tactic-scoped technique index (for hierarchical retrieval, v1.4) --------
# Load the technique -> tactic mapping added to the dictionary, and invert it to
# tactic -> techniques. This lets stage B offer the model only the techniques
# under a given tactic, rather than the whole catalogue.
_lookup_raw = json.loads(
    (Path(__file__).resolve().parent.parent / "data" / "attack_lookup.json")
    .read_text(encoding="utf-8"))
_TECHNIQUE_TACTICS = _lookup_raw.get("technique_tactics", {})
_TACTIC_TECHNIQUES: dict[str, list[str]] = {}
for _tid, _tacs in _TECHNIQUE_TACTICS.items():
    for _tac in _tacs:
        _TACTIC_TECHNIQUES.setdefault(_tac, []).append(_tid)


def _tech_lines_for_tactic(tactic: str) -> str:
    """The 'Tid = name' lines for techniques under one tactic, for stage B."""
    ids = sorted(_TACTIC_TECHNIQUES.get(tactic, []))
    return "\n".join(f"  {tid} = {_resolver._techniques.get(tid, '')}" for tid in ids)

# --- rule set: loaded from a versioned file so it can be iterated -----------
# The judgement rules that decide what a precondition, an event, and a logical
# element are, live in rules/ruleset_v<version>.md rather than in this file. This
# keeps the rule set explicit and version controlled: each iteration is a new
# file, and the tool can be pointed at a specific version for comparison. The
# ATT&CK catalogue is injected into the placeholders at load time.
_RULES_DIR = Path(__file__).resolve().parent.parent / "rules"
DEFAULT_RULESET = "v1"


def load_ruleset(version: str = DEFAULT_RULESET) -> str:
    """Read rules/ruleset_<version>.md and fill in the ATT&CK catalogue.

    Raises FileNotFoundError with a clear message if the version is missing, so
    a mistyped version fails loudly rather than silently using stale rules.
    """
    path = _RULES_DIR / f"ruleset_{version}.md"
    if not path.is_file():
        available = sorted(p.stem.replace("ruleset_", "")
                           for p in _RULES_DIR.glob("ruleset_*.md"))
        raise FileNotFoundError(
            f"rule set {version!r} not found at {path}. "
            f"available versions: {available or 'none'}"
        )
    text = path.read_text(encoding="utf-8")
    return text.format(
        tactic_lines=_TACTIC_LINES,
        tech_lines=_TECH_LINES,
        miti_lines=_MITI_LINES,
    )


# Built once from the default version for callers that do not choose a version.
SYSTEM_PROMPT = load_ruleset()

USER_TEMPLATE = """Here is the report. Extract the attack graph from it.

REPORT:
{report}"""


# --- hierarchical (two-stage) prompts, used by rule set v1.4 ----------------
# Stage A asks only for the graph skeleton with a tactic per event, choosing from
# the 14 tactics. Stage B then offers, per event, only the techniques under that
# event's tactic, and asks the model to pick the technique and mitigations. This
# keeps the model from searching the whole 700-technique catalogue at once.

STAGE_A_USER = """Here is a cyber incident report. Identify the attack as a graph
of alternating preconditions (ellipse states) and events (adversary actions).

For each EVENT give: a short id, a short label, the ATT&CK TACTIC it belongs to
(one of the 14 abbreviations), a likelihood 0-10, its join (AND or OR), and its
parent ids. Do NOT choose technique or mitigation ids yet; those come next.
For each PRECONDITION give: a short id, a short label, and its parent ids.

Model the whole attack the report describes, from reconnaissance to the final
objective, even where the report is brief or tentative. Return only the JSON.

REPORT:
{report}"""

STAGE_B_USER = """You previously produced this attack-graph skeleton, with a
tactic on each event but no technique or mitigation ids yet:

{events}

Your task is ONLY to assign a technique id and mitigation ids to each listed
event. Do not return a graph, preconditions, labels, parents, tactics, or join
values: the application preserves those from Stage A itself.

Return exactly one JSON object in this form:
{{"assignments": [
  {{"id": "event id from the list", "technique": "T#### or T####.###",
   "mitigations": ["M####"]}}
]}}

Return exactly {n_events} assignments, one per id, with no duplicate ids. The
required ids are: {event_ids}.

For each event choose the technique from ONLY the list under that event's tactic:

{candidates}

Mitigations to choose from (pick those that counter each event's technique):
{miti_lines}

Never leave a technique blank. Return only the assignments object."""


class TechniqueAssignment(BaseModel):
    """Stage B's small, immutable add-on for one Stage A event."""

    id: str
    technique: str = Field(..., description="ATT&CK T-number")
    mitigations: list[str] = Field(default_factory=list,
                                   description="ATT&CK mitigation M-numbers")

    @field_validator("technique")
    @classmethod
    def _known_technique(cls, value: str) -> str:
        if not TECHNIQUE_RE.match(value):
            raise ValueError("technique must be T#### or T####.###")
        if KNOWN_TECHNIQUES and value not in KNOWN_TECHNIQUES:
            raise ValueError(f"technique {value!r} is not in this ATT&CK catalogue")
        return value

    @field_validator("mitigations")
    @classmethod
    def _known_mitigations(cls, values: list[str]) -> list[str]:
        for value in values:
            if not MITIGATION_RE.match(value):
                raise ValueError("mitigation must be M####")
            if KNOWN_MITIGATIONS and value not in KNOWN_MITIGATIONS:
                raise ValueError(f"mitigation {value!r} is not in this ATT&CK catalogue")
        return values


class TechniqueAssignments(BaseModel):
    """The complete set of technique assignments for an existing skeleton."""

    assignments: list[TechniqueAssignment]



# ---------------------------------------------------------------------------
# providers
# ---------------------------------------------------------------------------
def _call_ollama(system: str, user: str, model: str,
                 response_model: type[BaseModel] = AttackGraph) -> str:
    """Local model through Ollama, constrained to the requested schema.

    Thinking mode is requested so a reasoning model (such as qwen3) works the
    steps out before emitting the JSON, which gives a fuller graph. Not every
    model supports it, so we fall back to a plain call if it is rejected.
    """
    import ollama
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": user}]
    schema = response_model.model_json_schema()
    try:
        resp = ollama.chat(model=model, messages=messages, format=schema,
                           think=True, options={"temperature": 0})
    except Exception:
        resp = ollama.chat(model=model, messages=messages, format=schema,
                           options={"temperature": 0})
    return resp["message"]["content"]


def _extract_json_text(s: str) -> str:
    """Pull a JSON object out of a text answer, tolerating fences or prose."""
    s = s.strip()
    if "```" in s:                          # strip ```json ... ``` fences
        s = s.split("```", 2)[1] if s.count("```") >= 2 else s
        if s.lstrip().lower().startswith("json"):
            s = s.lstrip()[4:]
    start, end = s.find("{"), s.rfind("}")
    if start != -1 and end != -1 and end > start:
        return s[start:end + 1]
    return s


def _call_anthropic(system: str, user: str, model: str,
                    response_model: type[BaseModel] = AttackGraph) -> str:
    """Claude API structured extraction for a graph or a graph add-on.

    Newer Claude models keep thinking on by default, which means a specific tool
    cannot be forced, so the tool is offered and the model is asked to use it.
    The response is read from the tool call when present, otherwise from any JSON
    the model wrote as text. max_tokens is generous because a full attack graph
    can be large and a truncated answer would carry no usable tool call.
    """
    import anthropic
    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from the environment
    tool = {
        "name": "emit_structured_result",
        "description": "Return the requested structured data.",
        "input_schema": response_model.model_json_schema(),
    }
    create_kwargs = dict(
        model=model,
        max_tokens=16384,
        system=system + "\n\nCall the emit_structured_result tool with the requested data.",
        tools=[tool],
        messages=[{"role": "user", "content": user}],
    )
    try:
        # turn thinking off so the whole budget goes to the answer, and force the tool
        msg = client.messages.create(
            **create_kwargs,
            thinking={"type": "disabled"},
            tool_choice={"type": "tool", "name": "emit_structured_result"},
        )
    except Exception:
        # some models keep thinking on and cannot force a tool; fall back to auto
        msg = client.messages.create(**create_kwargs, tool_choice={"type": "auto"})
    for block in msg.content:
        if getattr(block, "type", None) == "tool_use" and block.name == "emit_structured_result":
            return json.dumps(block.input)
    # fallback: a model that returned the JSON as text
    text = "".join(getattr(b, "text", "") for b in msg.content
                   if getattr(b, "type", None) == "text").strip()
    if text:
        return _extract_json_text(text)
    raise RuntimeError(
        f"model did not return the requested structured result (stop_reason={msg.stop_reason}); "
        f"content block types were {[getattr(b, 'type', '?') for b in msg.content]}"
    )


_PROVIDERS = {"ollama": _call_ollama, "anthropic": _call_anthropic}

_DEFAULT_MODELS = {"ollama": "qwen3:8b", "anthropic": "claude-sonnet-5"}


def _call_mock(system: str, user: str, model: str,
               response_model: type[BaseModel] = AttackGraph) -> str:
    """Offline stand-in for a model, so the pipeline can run with no setup.

    It returns a fixed, valid graph. Use it only to check that ingestion,
    validation, and rendering are wired together; it does not read the report.
    For the two-stage (v1.4) path it is stage-aware: stage A returns a skeleton
    with tactics but no technique ids, stage B returns the full graph.
    """
    from pathlib import Path
    canned = Path(__file__).resolve().parent.parent / "examples" / "mock_extraction.json"
    full = json.loads(canned.read_text(encoding="utf-8"))
    if response_model is TechniqueAssignments:
        return json.dumps({"assignments": [
            {"id": event["id"], "technique": event["technique"],
             "mitigations": event.get("mitigations", [])}
            for event in full.get("events", [])
        ]})
    # Stage A prompt asks not to choose technique ids yet; detect it and strip
    # techniques/mitigations so the mock mimics a tactic-only skeleton.
    if "Do NOT choose technique or mitigation ids yet" in user:
        skel = json.loads(json.dumps(full))
        for e in skel.get("events", []):
            e.pop("technique", None)
            e.pop("mitigations", None)
        return json.dumps(skel)
    return json.dumps(full)


_PROVIDERS["mock"] = _call_mock
_DEFAULT_MODELS["mock"] = "none"

def _structure_problems(graph: AttackGraph) -> list[str]:
    """Flag graphs that collapsed into a bare chain, so we can ask for a retry."""
    problems = []
    n_pre = len(graph.preconditions)
    n_ev = len(graph.events)
    if n_ev == 0:
        problems.append(
            "the graph has no events: the report narrates an attack (entry, "
            "movement, impact), so extract those steps as events. Model the "
            "attack the report describes; do not return an empty graph just "
            "because the report is brief or written in general terms")
        return problems                     # nothing else matters if it is empty
    if n_pre < max(2, n_ev // 2):
        problems.append(
            "too few preconditions: every attack step needs the state or "
            "resource it requires as an ellipse; add precondition nodes")
    has_multi_parent = any(len(e.parents) >= 2 for e in graph.events)
    if not has_multi_parent and n_ev >= 3:
        problems.append(
            "no AND/OR logic gate: at least one event should depend on several "
            "preconditions (AND) or offer an alternative path (OR)")
    events_producing_pre = {p.parents[0] for p in graph.preconditions if p.parents}
    if n_ev >= 3 and len(events_producing_pre) < 1:
        problems.append(
            "events do not establish preconditions: after an event, add the "
            "precondition it produces so nodes alternate")
    return problems

# ---------------------------------------------------------------------------
# extraction with validation and retry
# ---------------------------------------------------------------------------
def extract_attack_graph(report_text: str, provider: str = "ollama",
                         model: str | None = None, max_attempts: int = 3,
                         ruleset: str = DEFAULT_RULESET) -> AttackGraph:
    """Extract a validated AttackGraph from report text using the chosen provider.

    The ruleset argument selects which version of the rule set governs the
    extraction, so different versions can be compared on the same report.
    """
    if provider not in _PROVIDERS:
        raise ValueError(f"unknown provider {provider!r}; choose from {list(_PROVIDERS)}")
    call = _PROVIDERS[provider]
    model = model or _DEFAULT_MODELS[provider]

    # v1.4 onward uses tactic-first hierarchical retrieval; earlier versions use
    # the single-stage path below, kept intact so they still reproduce exactly.
    if ruleset.startswith("v1.4") or ruleset.startswith("v2"):
        return _extract_hierarchical(report_text, call, model, ruleset)

    system = load_ruleset(ruleset)
    user = USER_TEMPLATE.format(report=report_text)
    last_error = None

    for attempt in range(1, max_attempts + 1):
        raw = call(system, user, model)
        raw = _sanitize(raw)
        try:
            graph = AttackGraph.model_validate_json(raw)
            build_digraph(graph)  # also enforces acyclicity
            problems = _structure_problems(graph)
            if problems and attempt < max_attempts:
                raise ValueError("; ".join(problems))
            return graph
        except (ValidationError, ValueError) as e:
            last_error = e
            msg = str(e)
            if "no events" in msg:
                # An empty result needs a strong, front-loaded correction: the
                # directive goes BEFORE the report, where the model attends most.
                user = (
                    "IMPORTANT: your previous answer contained no attack steps. "
                    "This report DOES describe an attack. Read it for the sequence "
                    "of actions (reconnaissance, entry through a server, credential "
                    "theft, data taken, files encrypted, ransom) and extract each as "
                    "an event, even where the report is tentative or brief. Every "
                    "event needs a real technique id from the catalogue; never "
                    "return an empty graph.\n\n"
                    + USER_TEMPLATE.format(report=report_text))
            else:
                # feed the specific error back so the model can repair its output
                user = (USER_TEMPLATE.format(report=report_text) +
                        f"\n\nYour previous answer was rejected with this error:\n{e}\n"
                        f"Return a corrected object that fixes it.")

    raise RuntimeError(f"extraction failed after {max_attempts} attempts: {last_error}")


# ---------------------------------------------------------------------------
# hierarchical (two-stage) extraction, used by rule set v1.4
# ---------------------------------------------------------------------------
# Call budget per graph is fixed and small: stage A up to 2 calls (1 try + 1
# retry), stage B up to 2 calls (1 try + 1 retry). Worst case 4 model calls,
# normal case 2. The budget does not grow with the number of steps, because each
# stage handles all steps in a single call.
_STAGE_RETRIES = 1  # one retry per stage, as agreed


def _extract_hierarchical(report_text: str, call, model: str,
                          ruleset: str) -> AttackGraph:
    """Two-stage extraction: choose tactics first, then techniques per tactic."""
    system = load_ruleset(ruleset)

    # --- stage A: skeleton with a tactic on each event, no technique ids yet ---
    user_a = STAGE_A_USER.format(report=report_text)
    skeleton = None
    last_error = None
    for attempt in range(_STAGE_RETRIES + 1):
        raw = _sanitize(call(system, user_a, model))
        try:
            data = json.loads(raw)
            events = data.get("events", [])
            if not events:
                raise ValueError("stage A returned no events; extract the attack "
                                 "steps the report describes, each with a tactic")
            for e in events:
                if e.get("tactic") not in ATTACK_TACTICS:
                    raise ValueError(
                        f"event {e.get('id')} has tactic {e.get('tactic')!r}; "
                        f"use one of the 14 tactic abbreviations")
            skeleton = data
            break
        except (json.JSONDecodeError, ValueError) as ex:
            last_error = ex
            user_a = (STAGE_A_USER.format(report=report_text) +
                      f"\n\nYour previous answer had this problem:\n{ex}\n"
                      f"Return corrected JSON.")
    if skeleton is None:
        raise RuntimeError(f"stage A failed: {last_error}")

    # --- build per-tactic candidate lists for the tactics actually used --------
    used_tactics = sorted({e["tactic"] for e in skeleton["events"]})
    candidate_blocks = []
    for tac in used_tactics:
        lines = _tech_lines_for_tactic(tac)
        candidate_blocks.append(
            f"Techniques allowed for tactic {tac} "
            f"({ATTACK_TACTICS[tac]}):\n{lines}")
    candidates = "\n\n".join(candidate_blocks)

    # --- stage B: assign T/M values without re-emitting the graph --------------
    # Stage A's graph is deliberately kept in Python. Earlier versions asked the
    # model to reproduce the whole graph after choosing T/M values, which let a
    # long graph collapse to zero events during Stage B. Stage B now returns a
    # short id -> T/M mapping only; the preserved skeleton is then merged and
    # validated locally.
    skeleton_events_json = json.dumps(skeleton["events"], indent=2)
    n_events = len(skeleton["events"])
    event_ids = ", ".join(e["id"] for e in skeleton["events"])
    user_b = STAGE_B_USER.format(events=skeleton_events_json, n_events=n_events,
                                 event_ids=event_ids,
                                 candidates=candidates, miti_lines=_MITI_LINES)
    last_error = None
    for attempt in range(_STAGE_RETRIES + 1):
        raw = call(system, user_b, model, TechniqueAssignments)
        try:
            assignments = TechniqueAssignments.model_validate_json(raw).assignments
            assignment_ids = [assignment.id for assignment in assignments]
            expected_ids = [event["id"] for event in skeleton["events"]]
            if len(assignments) != n_events:
                raise ValueError(
                    f"stage B returned {len(assignments)} assignments but the skeleton "
                    f"has {n_events} events. Return one assignment for each id: "
                    f"{event_ids}.")
            if len(set(assignment_ids)) != n_events or set(assignment_ids) != set(expected_ids):
                raise ValueError(
                    "stage B assignments must contain every Stage A event id exactly "
                    f"once. Expected: {event_ids}. Returned: {', '.join(assignment_ids)}")

            by_id = {assignment.id: assignment for assignment in assignments}
            merged = json.loads(json.dumps(skeleton))
            for event in merged["events"]:
                assignment = by_id[event["id"]]
                event["technique"] = assignment.technique
                event["mitigations"] = assignment.mitigations
            graph = AttackGraph.model_validate(merged)
            # Each technique must belong to its event's tactic. The candidate list
            # was tactic-scoped, but the model can still stray, so this enforces
            # the tactic-technique consistency that hierarchical retrieval is meant
            # to guarantee, and asks for a corrected choice if it does not hold.
            mismatched = []
            for ev in graph.events:
                if ev.technique:
                    tacs = _TECHNIQUE_TACTICS.get(ev.technique, [])
                    if tacs and ev.tactic not in tacs:
                        mismatched.append(
                            f"{ev.id}: technique {ev.technique} belongs to "
                            f"{tacs}, not {ev.tactic}")
            if mismatched and attempt < _STAGE_RETRIES:
                raise ValueError(
                    "some techniques do not match their event's tactic; choose a "
                    "technique from the list for that tactic. " + "; ".join(mismatched))
            build_digraph(graph)
            problems = _structure_problems(graph)
            if problems and attempt < _STAGE_RETRIES:
                raise ValueError("; ".join(problems))
            return graph
        except (ValidationError, ValueError) as ex:
            last_error = ex
            user_b = (STAGE_B_USER.format(events=skeleton_events_json, n_events=n_events,
                                          event_ids=event_ids,
                                          candidates=candidates,
                                          miti_lines=_MITI_LINES) +
                      f"\n\nYour previous answer was rejected with this error:\n{ex}\n"
                      f"Return a corrected object that fixes it.")

    raise RuntimeError(f"stage B failed: {last_error}")


if __name__ == "__main__":
    import sys
    from ingest import ingest
    if len(sys.argv) < 2:
        print("usage: python extract.py <report.pdf|report.txt> [ollama|anthropic]")
        raise SystemExit(1)
    provider = sys.argv[2] if len(sys.argv) > 2 else "ollama"
    text = ingest(sys.argv[1])
    g = extract_attack_graph(text, provider=provider)
    print(f"[ok] extracted {len(g.preconditions)} preconditions, {len(g.events)} events")
    print(g.model_dump_json(indent=2))
