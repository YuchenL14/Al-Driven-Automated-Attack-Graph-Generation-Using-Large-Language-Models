"""
Demonstrates the renderer with a small slice of the supervisor's
Figure 5.0.1 example (the "fake Font Manager extension" phishing chain).

Run from the project root:
    python examples/sample_attack_graph.py
Output: output/sample_attack_graph.png
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from attack_graph import AttackGraph, Precondition, Event


def build():
    ag = AttackGraph("sample")

    # Preconditions (ellipses, code top-left)
    ag.add_precondition(Precondition("p_pdf", "Weaponised PDF requesting Font Manager extension", code="RS"))
    ag.add_precondition(Precondition("p_list", "Email list", code="R"))

    # Events (rectangles, four corner annotations)
    ag.add_event(Event("e_send", "Send email to targets containing PDF attachment",
                        marker="D", technique="T1566.02",
                        mitigations=["M1017", "M1041"], likelihood=5.0))
    ag.add_event(Event("e_open", "PDF opened",
                        marker="E", likelihood=4.0))
    ag.add_event(Event("e_perm", "Request permission to install Google Font Manager extension",
                        marker="E", technique="T1176",
                        mitigations=["M1021", "M1017", "M1041"], likelihood=4.0))
    ag.add_event(Event("e_inst", "Font Manager extension installed",
                        marker="I", technique="T1176",
                        mitigations=["M1021"], likelihood=4.0))

    # Edges (precondition -> event -> precondition -> ...)
    ag.connect("p_pdf", "e_send")
    ag.connect("p_list", "e_send")
    ag.connect("e_send", "e_open")
    ag.connect("e_open", "e_perm")
    ag.connect("e_perm", "e_inst")

    return ag


if __name__ == "__main__":
    ag = build()
    out = ag.render("output/sample_attack_graph")
    print(f"Wrote {out}")
