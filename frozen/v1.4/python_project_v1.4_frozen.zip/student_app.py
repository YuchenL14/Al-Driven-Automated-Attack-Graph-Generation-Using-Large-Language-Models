"""Student-facing text-entry interface for the frozen attack-graph pipeline.

This application deliberately reuses the established v1.4 extraction and
rendering pipeline without changing it.  ``app.py`` remains the professional
report-upload interface; this file offers the simpler workflow requested for
students: type an incident description, press Generate, and view the graph.

Run:
    python student_app.py
Then open http://127.0.0.1:5001
"""

from __future__ import annotations

import sys
from pathlib import Path

from flask import Flask, render_template_string, request, send_from_directory

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from attack_graph import render, tagged_output_path  # noqa: E402
from extract import extract_attack_graph  # noqa: E402


REPORTS_DIR = ROOT / "reports"
OUTPUTS_DIR = ROOT / "outputs"
REPORTS_DIR.mkdir(exist_ok=True)
OUTPUTS_DIR.mkdir(exist_ok=True)

# This is an interface version, not a new semantic rule set.  Keep the core
# system fixed while students use it, so their outputs remain comparable.
RULESET = "v1.4"
PROVIDER = "anthropic"

app = Flask(__name__)


def _next_submission_path() -> Path:
    """Return a new source-text path without overwriting a prior submission."""
    number = 1
    while True:
        path = REPORTS_DIR / f"student_submission_{number}.txt"
        if not path.exists():
            return path
        number += 1


def _friendly_error(error: Exception) -> str:
    message = str(error)
    lower = message.lower()
    if "api_key" in lower or "401" in lower or "authentication" in lower:
        return "The hosted model is not configured. Ask the instructor to check the API key."
    if "stage a failed" in lower:
        return ("No attack events could be identified. Add concrete attacker actions, "
                "preconditions, and outcomes, then try again.")
    if "stage b failed" in lower:
        return ("The graph structure was found, but technique mapping did not complete. "
                "Please try again or ask the instructor for support.")
    return f"Generation did not complete: {message}"


PAGE = """
<!doctype html>
<title>Student Attack Graph Generator</title>
<style>
  body { font-family: Helvetica, Arial, sans-serif; max-width: 1120px;
         margin: 40px auto; color: #1a1a2e; }
  h1 { color: #33415e; margin-bottom: 8px; }
  .card { border: 1px solid #d5dae2; border-radius: 8px; padding: 20px;
          margin: 20px 0; }
  textarea { box-sizing: border-box; width: 100%; min-height: 260px;
             resize: vertical; padding: 12px; font: 15px/1.45 Helvetica, Arial, sans-serif; }
  button { background: #33415e; color: white; border: none; padding: 10px 18px;
           border-radius: 6px; cursor: pointer; font-size: 15px; margin-top: 12px; }
  .muted { color: #667; font-size: 14px; }
  .err { color: #b23b3b; }
  img { max-width: 100%; }
  code { background: #f1f3f6; padding: 1px 4px; }
</style>
<h1>Student Attack Graph Generator</h1>
<p class="muted">Describe a cyber incident below. The system uses the frozen v1.4
attack-graph rules and saves your text and generated figure for review.</p>

<div class="card">
  <form method="post" action="/generate">
    <label for="scenario"><b>Incident description</b></label>
    <textarea id="scenario" name="scenario" required minlength="40"
      placeholder="Describe what the attacker did, what conditions enabled it, and what happened as a result.\n\nExample: An externally reachable service lacked multi-factor authentication. An attacker used stolen credentials to access the service, collected sensitive files, and encrypted systems for ransom.">{{ scenario or '' }}</textarea>
    <p class="muted">Include only information supported by your source. Avoid copying passwords, API keys, or personal data.</p>
    <button type="submit">Generate attack graph</button>
  </form>
</div>

{% if error %}<div class="card err"><b>Error:</b> {{ error }}</div>{% endif %}
{% if image %}
<div class="card">
  <p><b>{{ title }}</b> — {{ n_pre }} preconditions, {{ n_ev }} events</p>
  <p class="muted">Source saved as <code>{{ source_name }}</code>; graph saved as <code>{{ image }}</code>.</p>
  <img src="/outputs/{{ image }}" alt="Generated attack graph">
</div>
{% endif %}
"""


@app.route("/")
def index():
    return render_template_string(PAGE, scenario="", error=None, image=None)


@app.route("/generate", methods=["POST"])
def generate():
    scenario = (request.form.get("scenario") or "").strip()
    if len(scenario) < 40:
        return render_template_string(
            PAGE, scenario=scenario,
            error="Please provide at least a short incident description (40 characters).",
            image=None,
        )

    source_path = _next_submission_path()
    source_path.write_text(scenario, encoding="utf-8")
    output_stem = f"{source_path.stem}__rules-{RULESET}"
    output_path = tagged_output_path(OUTPUTS_DIR, output_stem, PROVIDER, None)

    try:
        graph = extract_attack_graph(scenario, provider=PROVIDER,
                                     ruleset=RULESET)
        render(graph, str(output_path), dpi=170)
    except Exception as error:
        return render_template_string(PAGE, scenario=scenario,
                                      error=_friendly_error(error), image=None)

    return render_template_string(
        PAGE, scenario="", error=None, image=output_path.name,
        source_name=source_path.name, title=graph.title,
        n_pre=len(graph.preconditions), n_ev=len(graph.events),
    )


@app.route("/outputs/<path:name>")
def outputs(name):
    return send_from_directory(str(OUTPUTS_DIR), name)


if __name__ == "__main__":
    app.run(debug=True, port=5001)
