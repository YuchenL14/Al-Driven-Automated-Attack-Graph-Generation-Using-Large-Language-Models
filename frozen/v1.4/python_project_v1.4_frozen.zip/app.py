"""
app.py -- a small web interface for the attack-graph tool.

Run it, open the page in a browser, upload a report, choose a model, and the
generated attack graph appears on the page. This wraps the same pipeline used on
the command line (ingest -> extract -> render); it does not change the tool, it
only gives it a front end.

    python app.py
    then open http://127.0.0.1:5000 in a browser
"""

import sys
from pathlib import Path

from flask import Flask, request, render_template_string, send_from_directory

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from ingest import ingest                     # noqa: E402
from extract import extract_attack_graph      # noqa: E402
from attack_graph import render, render_split, tagged_output_path # noqa: E402

REPORTS_DIR = ROOT / "reports"
OUTPUTS_DIR = ROOT / "outputs"
REPORTS_DIR.mkdir(exist_ok=True)
OUTPUTS_DIR.mkdir(exist_ok=True)

app = Flask(__name__)


def list_claude_models():
    """List the Claude models available to this account, with a fallback."""
    fallback = ["claude-sonnet-5", "claude-opus-4-8", "claude-sonnet-4-6",
                "claude-haiku-4-5-20251001"]
    try:
        import os
        if not os.environ.get("ANTHROPIC_API_KEY"):
            return fallback
        import anthropic
        ids = [m.id for m in anthropic.Anthropic().models.list().data]
        claude = [i for i in ids if i.startswith("claude-")]
        return claude or fallback
    except Exception:
        return fallback


CLAUDE_MODELS = list_claude_models()

# Local models suited to a 6-8 GB GPU (Ollama). Pull one before selecting it,
# e.g. `ollama pull qwen3:8b`.
OLLAMA_MODELS = ["qwen3:8b", "phi4-mini", "llama3.1:8b", "deepseek-r1:8b",
                 "gemma3:4b"]


def list_rulesets():
    """Discover rule set versions available under rules/, newest first."""
    rules_dir = ROOT / "rules"
    versions = sorted((p.stem.replace("ruleset_", "")
                       for p in rules_dir.glob("ruleset_*.md")), reverse=True)
    return versions or ["v1"]


RULESETS = list_rulesets()


def _friendly_error(e: Exception, provider: str) -> str:
    """Turn a raw exception into a clear message for the page."""
    msg = str(e)
    low = msg.lower()
    if "could not resolve authentication" in low or "api_key" in low or "401" in low:
        return ("No API key found. Set the ANTHROPIC_API_KEY environment "
                "variable before running the app, then restart it. "
                "(未找到 API 密钥：请先设置 ANTHROPIC_API_KEY 环境变量再启动。)")
    if "model" in low and ("not_found" in low or "404" in low or "not found" in low):
        return ("The model name was not recognised. Check the model name, or "
                "leave it blank to use the default. "
                "(模型名无法识别：请检查模型名，或留空使用默认。)")
    if "credit balance" in low or "billing" in low or "quota" in low:
        return ("The API account has no credit. Add credit in the Anthropic "
                "console. (API 账户余额不足：请在 Anthropic 控制台充值。)")
    if "max_tokens" in low:
        return ("The graph was too large for the model output limit. Try a "
                "shorter report, or raise max_tokens in the code. "
                "(图太大超出模型输出上限：请换更短的报告，或调大 max_tokens。)")
    if "no attack steps" in low or "produced no attack" in low:
        return ("No attack steps were found in this report. It may have little "
                "technical detail (for example a news article). Try a technical "
                "report. (未从报告中找到攻击步骤：该报告技术细节可能太少（如新闻文章）。请换一份技术报告。)")
    if provider == "ollama" and ("connection" in low or "refused" in low
                                 or "11434" in low):
        return ("Cannot reach Ollama. Make sure the Ollama app is running "
                "before using the local model. "
                "(无法连接 Ollama：使用本地模型前请确认 Ollama 已在后台运行。)")
    return f"Something went wrong: {msg}"

PAGE = """
<!doctype html>
<title>Attack Graph Generator</title>
<style>
  body { font-family: Helvetica, Arial, sans-serif; max-width: 1200px;
         margin: 40px auto; color: #1a1a2e; }
  h1 { color: #33415e; }
  .card { border: 1px solid #d5dae2; border-radius: 8px; padding: 20px;
          margin-bottom: 20px; }
  .row { display: flex; flex-wrap: wrap; align-items: center;
         column-gap: 12px; row-gap: 8px; }
  .row label { margin: 0; white-space: nowrap; }
  .row input[type=file] { max-width: 240px; }
  .row select { max-width: 210px; }
  label { font-weight: bold; display: inline-block; margin: 8px 8px 8px 0; }
  select, input[type=text] { padding: 6px; }
  button { background: #33415e; color: white; border: none; padding: 10px 18px;
           border-radius: 6px; cursor: pointer; font-size: 15px; }
  .err { color: #b23b3b; }
  img { max-width: 100%; }
  .muted { color: #667; font-size: 13px; }
</style>
<h1>Attack Graph Generator</h1>
<div class="card">
  <form method="post" action="/generate" enctype="multipart/form-data">
    <div class="row">
         <label title="PDF, TXT, or Markdown">Report:</label>
         <input type="file" name="report" accept=".pdf,.txt,.md" required>
         <label>Model:</label>
         <select name="provider" id="provider" onchange="syncModels()">
           <option value="anthropic">Claude API (hosted, richer)</option>
           <option value="ollama">Ollama (local, private)</option>
           <option value="mock">Mock (offline test)</option>
         </select>
         <span id="model_wrap" class="row">
         <label id="model_label">Claude model:</label>
         <select name="model" id="model"></select>
         </span>
         <label title="Which version of the judgement rules to apply">Rules:</label>
         <select name="ruleset" id="ruleset">
           {% for v in rulesets %}<option value="{{ v }}">{{ v }}</option>{% endfor %}
         </select>
         <label title="Tighter spacing produces a shorter figure">
           <input type="checkbox" name="compact" value="1"> Compact
         </label>
         <label title="Divide a long graph into an early and a late half by tactic">
           <input type="checkbox" name="split" value="1"> Split in two
         </label>
    </div>
    <p><button type="submit">Generate attack graph</button></p>
    <p class="muted">The report is saved to reports/. Each graph is saved to
       outputs/ with its rule set, model, and a sequential run number, so prior
       generations are retained.</p>
  </form>
</div>
{% if error %}<div class="card err"><b>Error:</b> {{ error }}</div>{% endif %}
{% if images %}
<div class="card">
  <p><b>{{ title }}</b> &mdash; {{ n_pre }} preconditions, {{ n_ev }} events</p>
  {% for im in images %}
  <img src="/outputs/{{ im }}" alt="attack graph" style="margin-bottom:14px;">
  {% endfor %}
</div>
{% endif %}

<script>
  const CLAUDE = {{ claude_models|tojson }};
  const OLLAMA = {{ ollama_models|tojson }};
  function fill(sel, items, withDefault) {
    sel.innerHTML = "";
    if (withDefault) {
      const o = document.createElement("option");
      o.value = ""; o.textContent = "Default"; sel.appendChild(o);
    }
    items.forEach(function(m) {
      const o = document.createElement("option");
      o.value = m; o.textContent = m; sel.appendChild(o);
    });
  }
  function syncModels() {
    const p = document.getElementById("provider").value;
    const wrap = document.getElementById("model_wrap");
    const label = document.getElementById("model_label");
    const sel = document.getElementById("model");
    if (p === "mock") { wrap.style.display = "none"; return; }
    wrap.style.display = "";
    if (p === "ollama") { label.textContent = "Local model:"; fill(sel, OLLAMA, false); }
    else { label.textContent = "Claude model:"; fill(sel, CLAUDE, true); }
  }
  syncModels();
</script>
"""


@app.route("/")
def index():
    return render_template_string(PAGE, images=None, error=None, claude_models=CLAUDE_MODELS, ollama_models=OLLAMA_MODELS, rulesets=RULESETS)


@app.route("/generate", methods=["POST"])
def generate():
    f = request.files.get("report")
    if not f or not f.filename:
        return render_template_string(PAGE, error="No file uploaded.", images=None, claude_models=CLAUDE_MODELS, ollama_models=OLLAMA_MODELS, rulesets=RULESETS)
    provider = request.form.get("provider", "mock")
    model = request.form.get("model") or None
    ruleset = request.form.get("ruleset") or "v1"
    compact = request.form.get("compact") == "1"
    split = request.form.get("split") == "1"

    report_path = REPORTS_DIR / Path(f.filename).name
    f.save(str(report_path))
    # fold the rule set version into the name so iterations do not overwrite
    stem = f"{report_path.stem}__rules-{ruleset}"
    out_path = tagged_output_path(OUTPUTS_DIR, stem, provider, model)

    try:
        text = ingest(report_path)
        graph = extract_attack_graph(text, provider=provider, model=model,
                                     ruleset=ruleset)
        if split:
            paths = render_split(graph, str(out_path), dpi=170, compact=compact)
            images = [Path(p).name for p in paths]
        else:
            render(graph, str(out_path), dpi=170, compact=compact)
            images = [out_path.name]
    except Exception as e:
        return render_template_string(PAGE, error=_friendly_error(e, provider),
                                      images=None, claude_models=CLAUDE_MODELS, ollama_models=OLLAMA_MODELS, rulesets=RULESETS)

    return render_template_string(
        PAGE, images=images, title=graph.title,
        n_pre=len(graph.preconditions), n_ev=len(graph.events), error=None,
        claude_models=CLAUDE_MODELS, ollama_models=OLLAMA_MODELS, rulesets=RULESETS)


@app.route("/outputs/<path:name>")
def outputs(name):
    return send_from_directory(str(OUTPUTS_DIR), name)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
