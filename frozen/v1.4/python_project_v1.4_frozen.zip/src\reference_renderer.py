"""Reference-style PNG renderer for the attack-graph application.

This module intentionally owns presentation only.  It consumes the existing
validated :class:`schema.AttackGraph` model, so report ingestion, LLM/API calls,
ATT&CK validation, output naming, and split-graph behaviour remain unchanged.

Graphviz is excellent at general diagrams, but its HTML labels place badges
*inside* nodes and its canvas changes with every graph.  The project reference
uses a different visual grammar: white ellipses/rectangles, circular badges
that overlap the node borders, small technique/mitigation stickers, orthogonal
connector buses, and an unboxed right-side legend.  Pillow gives us reliable
pixel-level control over those elements while this small layered layout keeps
the renderer useful for arbitrary graphs extracted from reports.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Iterable

import networkx as nx

from schema import ATTACK_TACTICS, AttackGraph

if TYPE_CHECKING:
    from attack_lookup import AttackResolver


# Palette sampled from SampleCyberAttackGraph.png.
WHITE = "#FFFFFF"
TEXT = "#222222"
BORDER = "#333333"
TACTIC = "#AFAFE9"
TECHNIQUE = "#FFAAAA"
LIKELIHOOD = "#37ABC8"
MITIGATION = "#FFCCAA"
TAG_BORDER = "#8D6B57"

NODE_W = 150
NODE_MIN_H = 92
BADGE_D = 26
SIDE_MARGIN = 14


@dataclass(frozen=True)
class _VisualNode:
    """One validated model object plus the geometry used to draw it."""

    id: str
    kind: str
    label: str
    code: str
    technique: str | None
    mitigations: tuple[str, ...]
    likelihood: float | None
    parents: tuple[str, ...]
    index: int
    level: int
    x: int = 0
    y: int = 0
    width: int = NODE_W
    height: int = NODE_MIN_H

    @property
    def cx(self) -> int:
        return self.x + self.width // 2

    @property
    def bottom(self) -> int:
        return self.y + self.height


def _load_fonts():
    """Use Arial when present; fall back cleanly on non-Windows systems."""
    try:
        from PIL import ImageFont
    except ImportError as exc:  # pragma: no cover - shown to users at runtime
        raise RuntimeError(
            "PNG reference rendering needs Pillow. Run `pip install -r "
            "requirements.txt` and try again."
        ) from exc

    candidates = (
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/Arial.ttf",
        "/Library/Fonts/Arial.ttf",
        "/usr/share/fonts/truetype/msttcorefonts/Arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    )

    def get(size: int):
        for path in candidates:
            if Path(path).is_file():
                return ImageFont.truetype(path, size=size)
        return ImageFont.load_default()

    return {
        "node": get(14),
        "badge": get(12),
        "tag": get(10),
        "legend": get(10),
    }


def _text_size(draw, text: str, font) -> tuple[int, int]:
    box = draw.textbbox((0, 0), text, font=font)
    return box[2] - box[0], box[3] - box[1]


def _wrap(draw, text: str, font, width: int) -> list[str]:
    """Word-wrap labels deterministically instead of relying on Graphviz."""
    lines: list[str] = []
    for paragraph in str(text).splitlines() or [""]:
        words = paragraph.split()
        if not words:
            lines.append("")
            continue
        line = words[0]
        for word in words[1:]:
            candidate = f"{line} {word}"
            if _text_size(draw, candidate, font)[0] <= width:
                line = candidate
            else:
                lines.append(line)
                line = word
        lines.append(line)
    return lines


def _draw_centered_lines(draw, lines: Iterable[str], center_x: int, center_y: int,
                         font, fill: str = TEXT, gap: int = 2) -> None:
    lines = list(lines)
    heights = [_text_size(draw, line, font)[1] for line in lines]
    total = sum(heights) + max(0, len(lines) - 1) * gap
    y = round(center_y - total / 2)
    for line, height in zip(lines, heights):
        width, _ = _text_size(draw, line, font)
        draw.text((round(center_x - width / 2), y), line, font=font, fill=fill)
        y += height + gap


def _draw_badge(draw, center: tuple[int, int], text: str, fill: str, font) -> None:
    x, y = center
    r = BADGE_D // 2
    draw.ellipse((x - r, y - r, x + r, y + r), fill=fill)
    _draw_centered_lines(draw, [text], x, y, font, gap=0)


def _draw_tag(draw, right: int, top: int, text: str, fill: str, font) -> tuple[int, int]:
    """Draw one small square-cornered sticker and return its dimensions."""
    tw, th = _text_size(draw, text, font)
    width, height = tw + 8, th + 4
    left = right - width
    draw.rectangle((left, top, right, top + height), fill=fill,
                   outline=TAG_BORDER, width=1)
    draw.text((left + 4, top + 2), text, font=font, fill=TEXT)
    return width, height


def _draw_arrow(draw, start: tuple[int, int], end: tuple[int, int]) -> None:
    """Draw a small arrowhead aligned with the final edge segment."""
    sx, sy = start
    ex, ey = end
    if abs(ex - sx) >= abs(ey - sy):
        direction = 1 if ex >= sx else -1
        points = [(ex, ey), (ex - 8 * direction, ey - 4),
                  (ex - 8 * direction, ey + 4)]
    else:
        direction = 1 if ey >= sy else -1
        points = [(ex, ey), (ex - 4, ey - 8 * direction),
                  (ex + 4, ey - 8 * direction)]
    draw.polygon(points, fill=BORDER)


def _build_nodes(model: AttackGraph) -> dict[str, _VisualNode]:
    """Build the visual model while retaining the validated graph semantics."""
    raw: dict[str, dict] = {}
    index = 0
    for p in model.preconditions:
        raw[p.id] = {
            "kind": "precondition", "label": p.label, "code": p.code,
            "technique": None, "mitigations": (), "likelihood": None,
            "parents": tuple(p.parents), "index": index,
        }
        index += 1
    for e in model.events:
        raw[e.id] = {
            "kind": "event", "label": e.label, "code": e.tactic,
            "technique": e.technique, "mitigations": tuple(e.mitigations),
            "likelihood": e.likelihood, "parents": tuple(e.parents),
            "index": index,
        }
        index += 1

    graph = nx.DiGraph()
    graph.add_nodes_from(raw)
    for node_id, info in raw.items():
        graph.add_edges_from((parent, node_id) for parent in info["parents"])

    levels: dict[str, int] = {}
    for node_id in nx.topological_sort(graph):
        parents = raw[node_id]["parents"]
        levels[node_id] = 0 if not parents else max(levels[p] for p in parents) + 1

    return {
        node_id: _VisualNode(id=node_id, level=levels[node_id], **info)
        for node_id, info in raw.items()
    }


def _layout(draw, nodes: dict[str, _VisualNode], node_font, compact: bool) -> dict[str, _VisualNode]:
    """Pack a topological sequence into landscape rows.

    A conventional rank-per-row layout makes an alternating attack graph twice
    as tall as its number of actions.  The reference figure instead presents a
    small number of compact rows.  We therefore retain topological order (every
    parent appears before its child), but place four nodes across before moving
    to the next row.  This makes a 15-step incident readable at approximately
    the reference figure's 1248x706 scale instead of a many-thousand-pixel
    portrait strip.
    """
    graph = nx.DiGraph()
    graph.add_nodes_from(nodes)
    for node in nodes.values():
        graph.add_edges_from((parent, node.id) for parent in node.parents)

    order = list(nx.topological_sort(graph))
    per_row = 5 if compact else 4
    graph_width = max(828, per_row * NODE_W + (per_row - 1) * 40 + 42)
    spacing = (graph_width - 42 - per_row * NODE_W) / max(1, per_row - 1)

    sized: list[_VisualNode] = []
    for node_id in order:
        node = nodes[node_id]
        label_lines = _wrap(draw, node.label, node_font, NODE_W - 20)
        label_h = sum(_text_size(draw, line, node_font)[1] for line in label_lines)
        sized.append(_VisualNode(**{**node.__dict__, "height": max(NODE_MIN_H, label_h + 34)}))

    positioned: dict[str, _VisualNode] = {}
    y = 43
    for row_start in range(0, len(sized), per_row):
        row = sized[row_start:row_start + per_row]
        row_h = max(node.height for node in row)
        for column, node in enumerate(row):
            x = round(21 + column * (NODE_W + spacing))
            positioned[node.id] = _VisualNode(**{**node.__dict__, "x": x, "y": y})
        y += row_h + (28 if compact else 38)
    return positioned


def _legend_lines(model: AttackGraph, resolver: "AttackResolver") -> list[str]:
    """Use the sample's plain, grouped code list instead of a boxed table."""
    techniques: dict[str, str] = {}
    mitigations: dict[str, str] = {}
    used_tactics: dict[str, str] = {}
    for event in model.events:
        used_tactics[event.tactic] = ATTACK_TACTICS.get(event.tactic, "Unknown tactic")
        if event.technique:
            techniques[event.technique] = resolver.resolve_technique(event.technique)
        for mitigation in event.mitigations:
            mitigations[mitigation] = resolver.resolve_mitigation(mitigation)

    lines = [f"{code}: {name}" for code, name in sorted(techniques.items())]
    if mitigations:
        lines.append("")
        lines.extend(f"{code}: {name}" for code, name in sorted(mitigations.items()))
    if used_tactics:
        lines.append("")
        lines.extend(f"{code}: {name}" for code, name in used_tactics.items())
    return lines


def render_reference_png(model: AttackGraph, out_path: str,
                         resolver: "AttackResolver | None" = None,
                         compact: bool = False) -> str:
    """Render the validated graph in the ``SampleCyberAttackGraph`` style."""
    try:
        from PIL import Image, ImageDraw
    except ImportError as exc:  # pragma: no cover - shown to users at runtime
        raise RuntimeError(
            "PNG reference rendering needs Pillow. Run `pip install -r "
            "requirements.txt` and try again."
        ) from exc

    if resolver is None:
        from attack_lookup import AttackResolver
        resolver = AttackResolver()

    fonts = _load_fonts()
    # A temporary surface lets us measure wrapped text before knowing the final
    # graph height and right-side legend width.
    measure = Image.new("RGBA", (8, 8), WHITE)
    measure_draw = ImageDraw.Draw(measure)
    nodes = _layout(measure_draw, _build_nodes(model), fonts["node"], compact)
    graph_right = max((node.x + node.width for node in nodes.values()), default=828)
    sticker_w = max(
        (_text_size(measure_draw, text, fonts["tag"])[0] + 8
         for node in nodes.values()
         for text in ((node.technique,) if node.technique else ()) + node.mitigations),
        default=0,
    )
    # Tags deliberately sit outside event nodes.  Reserve their full width so
    # an automatically larger T/M identifier can never collide with the legend.
    legend_x = max(860, graph_right + sticker_w + 20)
    legend = _legend_lines(model, resolver)
    legend_w = max((_text_size(measure_draw, line, fonts["legend"])[0]
                    for line in legend), default=0)
    legend_h = len(legend) * 12
    graph_h = max((node.bottom for node in nodes.values()), default=0) + 44
    canvas_w = max(1248, legend_x + legend_w + 18)
    canvas_h = max(706, graph_h, 202 + legend_h + 18)

    image = Image.new("RGBA", (canvas_w, canvas_h), WHITE)
    draw = ImageDraw.Draw(image)

    # Edges are placed behind the nodes.  Within a row they read left-to-right;
    # between rows they use a short horizontal bus above the child.  This keeps
    # wrapped landscape rows understandable without reintroducing Graphviz's
    # large AND/OR diamonds.
    for target in sorted(nodes.values(), key=lambda n: (n.level, n.index)):
        parents = [nodes[parent] for parent in target.parents if parent in nodes]
        if not parents:
            continue
        for parent in parents:
            if parent.y == target.y:
                start = (parent.x + parent.width, parent.y + parent.height // 2)
                end = (target.x, target.y + target.height // 2)
                draw.line((start, end), fill=BORDER, width=1)
                _draw_arrow(draw, start, end)
                continue

            start = (parent.cx, parent.bottom)
            bus_y = target.y - 20
            end = (target.cx, target.y)
            draw.line((start, (parent.cx, bus_y)), fill=BORDER, width=1)
            draw.line(((parent.cx, bus_y), (target.cx, bus_y)), fill=BORDER, width=1)
            draw.line(((target.cx, bus_y), end), fill=BORDER, width=1)
            _draw_arrow(draw, (target.cx, bus_y), end)

    # Nodes and their external badges/stickers.
    for node in sorted(nodes.values(), key=lambda n: (n.level, n.index)):
        bbox = (node.x, node.y, node.x + node.width, node.bottom)
        if node.kind == "precondition":
            draw.ellipse(bbox, fill=WHITE, outline=BORDER, width=2)
        else:
            draw.rectangle(bbox, fill=WHITE, outline=BORDER, width=1)

        lines = _wrap(draw, node.label, fonts["node"], node.width - 20)
        _draw_centered_lines(draw, lines, node.cx, node.y + node.height // 2,
                             fonts["node"])
        _draw_badge(draw, (node.x - 2, node.y - 4), node.code, TACTIC,
                    fonts["badge"])

        if node.kind == "event":
            if node.technique:
                _draw_tag(draw, node.x + node.width + 1, node.y - 8,
                          node.technique, TECHNIQUE, fonts["tag"])
            if node.likelihood is not None:
                _draw_badge(draw, (node.x + 1, node.bottom - 1),
                            f"{node.likelihood:.1f}", LIKELIHOOD,
                            fonts["badge"])
            tag_y = node.bottom - 12
            for mitigation in reversed(node.mitigations):
                _, tag_h = _draw_tag(draw, node.x + node.width + 1, tag_y,
                                     mitigation, MITIGATION, fonts["tag"])
                tag_y -= tag_h + 1

    # Right-side legend: compact, plain text, and intentionally unboxed.
    legend_y = 202
    for line in legend:
        if line:
            draw.text((legend_x, legend_y), line, font=fonts["legend"], fill=TEXT)
        legend_y += 12

    output = Path(out_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output, format="PNG")
    return str(output)
